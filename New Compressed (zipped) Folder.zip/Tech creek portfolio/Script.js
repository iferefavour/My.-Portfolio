const projects = [
  {
    title: "Portfolio Website",
    description: "A responsive portfolio to showcase my work.",
  },
  {
    title: "Solar Discovery",
    description: "Solar Discovery features planet profiles, fun facts, animations, and a responsive layout. Built with HTML, CSS, and JavaScript, it's perfect for students or anyone curious about space.",
  },
  {
    title: "Todo List",
    description: "A simple to-do list app with localStorage.",
  },
  {
    title: "Weather App",
    description: "The weather app fetches data from API and displays current weather conditions."
  },
  {
    title: "Real-time Data Analytics",
    description: "It displays real-time data analytics using tools like Tableau, Power BI or D3.js"
  },
  {
    title: "Online Store",
    description: "An e-commerce website for a special product or niche."
  },
  {
    title: "Marketplace Platform",
    description: "A platform for buying and selling goods or services."
  },
  {
    title: "Product Recommendation Engine",
    description: "A system that recommends products based on user behavior."
  }
];

// Display projects dynamically
const projectList = document.getElementById("project-list");

projects.forEach(project => {
  const card = document.createElement("div");
  card.className = "project-card";
  card.innerHTML = `<h3>${project.title}</h3><p>${project.description}</p>`;
  projectList.appendChild(card);
});

// Theme toggle
function setupThemeToggle() {
  const toggle = document.getElementById("theme-toggle");

  toggle.addEventListener("click", () => {
    const root = document.documentElement;
    const isDark = document.body.classList.toggle("dark-mode");

    if (isDark) {
      root.style.setProperty("--accent-color", "#4db6ac");
      root.style.setProperty("--link-color", "#4db6ac");
      toggle.textContent = "🌙";
    } else {
      root.style.setProperty("--accent-color", "#007bff");
      root.style.setProperty("--link-color", "#1a73e8");
      toggle.textContent = "☀️";
    }
  });
}

setupThemeToggle();

// Scroll animations
const fadeElements = document.querySelectorAll("#about, #skills, #contact, #projects, footer, h1, #nav-links");

const observer = new IntersectionObserver(
  entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("fade-in");
      }
    });
  },
  { threshold: 0.1 }
);

fadeElements.forEach(el => observer.observe(el));




document.getElementById("contact-form").addEventListener("submit", async function (e) {
  e.preventDefault();

  const form = e.target;
  const formData = new FormData(form);
  const statusDiv = document.getElementById("form-status");

  try {
    const response = await fetch("/api/contact", {
      method: "POST",
      body: JSON.stringify(Object.fromEntries(formData)),
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (response.ok) {
      form.reset();
      statusDiv.textContent = "Message sent successfully!";
      statusDiv.style.color = "green";
    } else {
      statusDiv.textContent = "Error sending message.";
      statusDiv.style.color = "red";
    }
  } catch (err) {
    statusDiv.textContent = "Server error.";
    statusDiv.style.color = "red";
  }
});

const express = require("express");
const nodemailer = require("nodemailer");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

app.post("/send", async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: "All fields required" });
  }
  try {
    let transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL,
        pass: process.env.PASSWORD,
      },
    });

    await transporter.sendMail({
      from: email,
      to: process.env.EMAIL,
      subject: `Contact Form Submission from ${name}`,
      text: message,
    });

    res.json({ success: true, message: "Message sent" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to send message" });
  }
});

app.listen(3000, () => console.log("Server running on port 3000"));



async function sendMessage(data) {
  const response = await fetch("http://localhost:3000/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return response.json();
}

